import { FC } from "react";

const Home: FC = () => {
  return (
    <>
      <h1>Welcome to the Telegram chat viewer system.</h1>
    </>
  );
};
export default Home;
