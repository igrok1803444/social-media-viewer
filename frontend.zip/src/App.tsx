import React, { FC, lazy, useState } from "react";
import "./App.css";
import { Route, Routes } from "react-router-dom";
import Layot from "./components/Layot/Layot";
import { PublicRoute } from "./routes/PublicRoute";
import { PrivateRoute } from "./routes/PrivateRoute";

const HomePage = React.lazy(() => import("./pages/Home/Home"));

const App: FC = () => {
  const [count, setCount] = useState(0);

  return (
    <Routes>
      <Route path="/" element={<Layot />}>
        <Route index element={<HomePage />} />
        {/* <Route
          path="/register"
          element={<PublicRoute redirectTo="/chats" component={<AuthPage />} />}
        />
        <Route
          path="/login"
          element={<PublicRoute redirectTo="/chats" component={<AuthPage />} />}
        />
        <Route
          path="/chats"
          element={<PrivateRoute component={<ChatsPage />} />}
        />
        <Route
          path="/chats/:id"
          element={<PrivateRoute component={<ChatMessagesPage />} />}
        /> */}
      </Route>
    </Routes>
  );
};

export default App;
