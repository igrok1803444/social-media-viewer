import { createSlice } from "@reduxjs/toolkit";
import { register } from "./auth.operations";
import { IUserSate } from "../../types/auth";

const initialState: IUserSate = {
  access_token: "",
  refresh_token: "",
  user: {
    username: "",
    email: "",
    _id: "",
  },
  isLoggedIn: false,
  isLoading: false,
};

const authSlice = createSlice({
  name: "users",
  initialState,
  reducers: {},
  extraReducers(builder) {
    builder
      .addCase(register.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(register.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(register.fulfilled, (state, { payload }) => {
        state.isLoading = false;
        state.isLoggedIn = true;
        state.user = payload.user;
        state.access_token = payload.access_token;
      });
  },
});
export const authSliceReducer = authSlice.reducer;
