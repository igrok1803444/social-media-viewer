import { createAsyncThunk } from "@reduxjs/toolkit";
import { instance } from "../../config/axios/axios";
import { IError } from "../../types/error";

const setAuthHeader = (token: string) => {
  instance.defaults.headers.common.Authorization = `Bearer ${token}`;
};

const clearAuthHeader = () => {
  instance.defaults.headers.common.Authorization = "";
};

export const register = createAsyncThunk(
  "users/register",
  async (data, { rejectWithValue }) => {
    try {
      const response = await instance.post("users/register", data);
      setAuthHeader(response.data.access_token);
      return response.data;
    } catch (error) {
      const typedError = error as IError;
      if (typedError.message) {
        return rejectWithValue(typedError.message);
      } else {
        return rejectWithValue(
          "An unknown error occurred during registration."
        );
      }
    }
  }
);
