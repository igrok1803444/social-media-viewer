import { configureStore } from "@reduxjs/toolkit";
import { authSliceReducer } from "./auth/auth.slice";

const store = configureStore({
  reducer: {
    auth: authSliceReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActionPaths: [
          "payload.headers",
          "payload.config",
          "payload.request",
          "payload.config.transformRequest",
          "payload.config.transformResponse",
        ],
        ignoredPaths: ["auth.token", "auth.user"],
      },
    }),
});

export default store;
export type RootState = ReturnType<typeof store.getState>;
