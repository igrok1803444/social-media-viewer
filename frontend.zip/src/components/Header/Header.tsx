import { FC } from "react";
import { useSelector } from "react-redux";
import { selectIsLoggedIn } from "../../redux/auth/auth.selectors";

import styles from "./Header.module.css";
import Navigation from "../Navigation/Navigation";
import AuthNavigation from "../AuthNavigation/AuthNavigation";

const Header: FC = () => {
  const isLoggedIn = useSelector(selectIsLoggedIn);
  return (
    <header className={styles.header}>
      <Navigation />
      <AuthNavigation />
    </header>
  );
};
export default Header;
