import { useSelector } from "react-redux";

import { selectIsLoggedIn } from "../../redux/auth/auth.selectors";
import style from "./AuthNavigation.module.css";
import NavigationLink from "../Navlink/NavigationLink";

const AuthNavigation = () => {
  const isLoggedIn = useSelector(selectIsLoggedIn);
  console.log(isLoggedIn);

  return (
    <nav className={style.nav}>
      {isLoggedIn ? (
        <>
          <NavigationLink to="logout" text="Logout" />
        </>
      ) : (
        <>
          <NavigationLink to="register" text="Register" />
          <NavigationLink to="login" text="Login" />
        </>
      )}
    </nav>
  );
};
export default AuthNavigation;
